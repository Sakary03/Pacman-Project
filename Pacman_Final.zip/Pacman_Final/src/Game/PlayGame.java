package Game;
import javax.swing.JFrame;


public class PlayGame extends JFrame {


        private static final long serialVersionUID = 1L;
        public PlayGame() {
            add(new Game_Components());
        }
        public static void main(String[] args) {
            PlayGame pac = new PlayGame();
            pac.setVisible(true);
            pac.setTitle("Pacman");
            pac.setSize(620,420);
            pac.setDefaultCloseOperation(EXIT_ON_CLOSE);
            pac.setLocationRelativeTo(null);

        }

    }


