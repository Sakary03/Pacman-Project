package Game;

import javax.swing.*;
import java.awt.event.ActionListener;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
    public class Game_Components extends JPanel implements ActionListener {


        private static final long serialVersionUID = 1L;
        private Dimension d;
        private final Font smallFont = new Font("Times New Roman", Font.BOLD, 14);
        private boolean inGame = false;
        private boolean dying = false;
        private int nLevel = 2;
        private int currentLevel = 1;
        private boolean isRS = false;

        private final int BLOCK_SIZE = 24;
        private final int N_BLOCKSWIDTH = 25;

        private final int N_BLOCKSHEIGHT = 15;
        private final int SCREEN_SIZEWIDTH = N_BLOCKSWIDTH * BLOCK_SIZE;
        private final int SCREEN_SIZEHEIGHT = N_BLOCKSHEIGHT * BLOCK_SIZE;
        private final int MAX_GHOSTS = 8;
        private final int PACMAN_SPEED = 3;

        private int N_GHOSTS = 6;
        private int lives, score;
        private int[] dx, dy;
        private int[] ghost_x, ghost_y, ghost_dx, ghost_dy, ghostSpeed;

        private Image heart, ghost, portal;
        private Image up, down, left, right, wall;

        //portal
        private final int MAX_PORTAL = 2;
        private int[] portal_x, portal_y;
        private int[] portal_pos;
        int nPortal;

        private int pacman_x, pacman_y, pacmand_x, pacmand_y;
        private int req_dx, req_dy;
        private short clearArr[];

        //dot: 259
        private final int DOT_1 = 259;
        private final short levelData[] = {
                19, 26, 26, 26, 18, 18, 26, 26, 26, 26, 26, 18, 18, 18, 26, 26, 26, 26, 26, 18, 18, 26, 26, 26, 22,
                21,  0,  0,  0, 17, 20,  0,  0,  0,  0,  0, 17, 16, 20,  0,  0,  0,  0,  0, 17, 20,  0,  0, 0, 21,
                17, 26, 26, 26, 16, 16, 26, 18, 26, 26, 26, 24, 24, 24, 26, 26, 26, 18, 26, 16, 16, 26, 26, 26, 20,
                21,  0, 0, 0, 17, 20, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 21, 0, 17, 20, 0, 0, 0, 21,
                17, 22, 0, 19, 24, 20, 0, 25, 26, 18, 22, 0, 0, 0, 19, 18, 26, 28, 0, 17, 24, 22, 0, 19, 20,
                17, 20, 0, 21, 0, 21, 0, 0, 0, 17, 20, 0, 0, 0, 17, 20, 0, 0, 0, 21, 0, 21, 0, 17, 20,
                17, 16, 26, 28, 0, 21, 0, 19, 18, 16, 16, 18, 18, 18, 16, 16, 18, 22, 0, 21, 0, 25, 26, 16, 20,
                17, 20, 0, 0, 0, 21, 0, 17, 16, 16, 16, 16, 16, 16, 16, 16, 16, 20, 0, 21, 0, 0, 0, 17, 20,
                25, 24, 26, 18, 18, 16, 18, 16, 16, 24, 24, 24, 24, 24, 24, 24, 16, 16, 18, 16, 18, 18, 26, 24, 28,
                0, 0, 0, 17, 16, 16, 24, 24, 20, 0, 0, 0, 0, 0, 0, 0, 17, 24, 24, 16, 16, 20, 0, 0, 0,
                27, 22, 0, 17, 24, 20, 0, 0, 17, 18, 22, 0, 0, 0, 19, 18, 20, 0, 0, 17, 24, 20, 0, 19, 30,
                0, 21, 0, 21, 0, 21, 0, 0, 17, 16, 16, 22, 0, 19, 16, 16, 20, 0, 0, 21, 0, 21, 0, 21, 0,
                19, 24, 26, 28,  0, 25, 26, 18, 16, 24, 24, 16, 18, 16, 24, 24, 16, 18, 26, 28, 0, 25, 26, 24, 22,
                21,  0,  0,  0,  0,  0,  0, 17, 20,  0,  0, 17, 16, 20,  0,  0, 17, 20, 0, 0, 0, 0, 0, 0, 21,
                25, 26, 26, 26, 26, 26, 26, 24, 24, 26, 26, 24, 24, 24, 26, 26, 24, 24, 26, 26, 26, 26, 26, 26, 28


        };
        //dot: 238
        private final int DOT_2 = 238 + 6;
        private final short levelData1[] = {
                19,	26,	26,	26,	18,	22,	0,	0,	0,	0,	19,	18,	18,	18,	22,	0,	0,	0,	0,	19,	18,	26,	26,	26,	22,
                21,	0,	0,	0,	17,	64,	18,	18,	18,	26,	24,	24,	24,	24,	24,	26,	18,	18,	18,	16,	20,	0,	0,	0,	21,
                21,	0,	19,	18,	24,	24,	24,	16,	20,	0,	0,	0,	0,	0,	0,	0,	17,	16,	24,	24,	24,	18,	22,	0,	21,
                21,	0,	17,	20,	0,	0,	0,	17,	16,	18,	22,	0,	0,	0,	19,	18,	16,	20,	0,	0,	0,	17,	20,	0,	21,
                17,	18,	24,	24,	18,	22,	0,	17,	24,	16,	16,	22,	0,	19,	16,	16,	24,	20,	0,	19,	18,	24,	24,	18,	20,
                25,	20,	0,	0,	25,	20,	0,	21,	0,	25,	16,	24,	26,	24,	16,	28,	0,	21,	0,	17,	28,	0,	0,	17,	28,
                0,	21,	0,	0,	0,	17,	18,	20,	0,	0,	21,	19,	18,	22,	21,	0,	0,	17,	18,	20,	0,	0,	0,	21,	0,
                0,	21,	0,	0,	43,	16,	16,	20,	0,	0,	21,	25,	16,	28,	21,	0,	0,	17,	16,	64,	46,	0,	0,	21,	0,
                0,	21,	0,	0,	0,	17,	24,	20,	0,	0,	17,	18,	16,	18,	20,	0,	0,	17,	24,	20,	0,	0,	0,	21,	0,
                19,	20,	0,	0,	19,	20,	0,	21,	0,	19,	16,	24,	24,	24,	16,	22,	0,	21,	0,	17,	22,	0,	0,	17,	22,
                17,	24,	18,	18,	24,	28,	0,	17,	18,	16,	28,	0,	0,	0,	25,	16,	18,	20,	0,	25,	24,	18,	18,	24,	20,
                21,	0,	17,	20,	0,	0,	0,	17,	16,	28,	0,	0,	0,	0,	0,	25,	16,	20,	0,	0,	0,	17,	20,	0,	21,
                21,	0,	25,	24,	18,	18,	18,	16,	20,	0,	0,	0,	23,	0,	0,	0,	17,	16,	18,	18,	18,	24,	28,	0,	21,
                21,	 0,	 0,	 0,	17,	16,	24,	24,	24,	26,	18,	18,	16,	18,	18,	26,	24,	24,	24,	16,	20,	0,	0,	0,	21,
                25,	26,	26,	26,	24,	28,	0,	0,	0,	0,	25,	24,	24,	24,	28,	0,	0,	0,	0,	25,	24,	26,	26,	26,	28


        };
        //dot: 235
        private final int DOT_3 = 235 + 16;
        private final short levelData2[] = {
                0,	0,	0,	19,	18,	26,	26,	26,	18,	18,	26,	26,	26,	26,	26,	18,	18,	26,	26,	26,	18,	22,	0,	0,	0,
                19,	18,	26,	24,	20,	0,	0,	0,	17,	20,	0,	0,	0,	0,	0,	17,	20,	0,	0,	0,	17,	24,	26,	18,	22,
                25,	20,	0,	0,	21,	0,	19,	26,	24,	16,	22,	0,	0,	0,	19,	16,	24,	26,	22,	0,	21,	0,	0,	17,	28,
                0,	21,	0,	0,	21,	0,	21,	0,	0,	17,	24,	22,	0,	19,	24,	20,	0,	0,	21,	0,	21,	0,	0,	21,	0,
                0,	25,	26,	18,	16,	18,	20,	0,	0,	21,	23,	17,	18,	20,	23,	21,	0,	0,	17,	18,	64,	18,	26,	28,	0,
                0,	0,	0,	17,	16,	24,	16,	18,	26,	28,	21,	25,	16,	28,	21,	25,	26,	18,	16,	24,	16,	20,	0,	0,	0,
                19,	26,	26,	24,	20,	0,	17,	20,	27,	26,	24,	18,	16,	18,	24,	26,	30,	17,	20,	0,	17,	24,	26,	26,	22,
                21,	0,	0,	0,	21,	0,	17,	16,	18,	18,	22,	25,	24,	28,	19,	18,	18,	16,	20,	0,	21,	0,	0,	0,	21,
                25,	26,	26,	18,	20,	0,	17,	16,	24,	24,	24,	26,	26,	26,	24,	24,	24,	16,	20,	0,	17,	18,	26,	26,	28,
                0,	0,	0,	17,	20,	0,	17,	20,	0,	0,	0,	0,	0,	0,	0,	0,	0,	17,	20,	0,	17,	20,	0,	0,	0,
                0,	19,	26,	24,	64,	18,	16,	16,	26,	18,	18,	26,	58,	26,	18,	18,	26,	16,	16,	18,	16,	24,	26,	22,	0,
                0,	21,	0,	0,	17,	24,	16,	20,	0,	17,	20,	0,	0,	0,	17,	20,	0,	17,	16,	24,	20,	0,	0,	21,	0,
                27,	20,	0,	0,	21,	0,	17,	20,	0,	25,	24,	18,	26,	18,	24,	28,	0,	17,	20,	0,	21,	0,	0,	17,	30,
                0,	25,	18,	26,	28,	0,	17,	20,	0,	0,	0,	21,	0,	21,	0,	0,	0,	17,	20,	0,	25,	26,	18,	28,	0,
                0,	0,	29,	0,	0,	0,	25,	24,	26,	26,	26,	24,	26,	24,	26,	26,	26,	24,	28,	0,	0,	0,	29,	0,	0


        };
        private final int validSpeeds[] = {1, 2, 3, 4, 6, 8};
        //private final int maxSpeed = 6;

        private int currentSpeed = 3;
        private short[] screenData;
        private Timer timer;

        public Game_Components() {

            loadImages();
            initVariables();
            addKeyListener(new TAdapter());
            setFocusable(true);
            initGame();
        }


        private void loadImages() {
            down = new ImageIcon(this.getClass().getResource("/images/down.gif")).getImage();
            up = new ImageIcon(this.getClass().getResource("/images/up.gif")).getImage();
            left = new ImageIcon(this.getClass().getResource("/images/left.gif")).getImage();
            right = new ImageIcon(this.getClass().getResource("/images/right.gif")).getImage();
            ghost = new ImageIcon(this.getClass().getResource("/images/ghost.gif")).getImage();
            portal = new ImageIcon(this.getClass().getResource("/images/portal.gif")).getImage();
            heart = new ImageIcon(this.getClass().getResource("/images/heart.png")).getImage();
            wall = new ImageIcon(this.getClass().getResource("/images/wall.png")).getImage();

        }
        private void initVariables() {

            screenData = new short[N_BLOCKSWIDTH * N_BLOCKSHEIGHT];
            setD(new Dimension(400, 400));
            ghost_x = new int[MAX_GHOSTS];
            ghost_dx = new int[MAX_GHOSTS];
            ghost_y = new int[MAX_GHOSTS];
            ghost_dy = new int[MAX_GHOSTS];
            ghostSpeed = new int[MAX_GHOSTS];
            dx = new int[4];
            dy = new int[4];
//        pp = new int[2];
//        pp[0] = 151;
//        pp[1] = 316;
            //portal
            portal_x = new int[MAX_PORTAL];
            portal_y = new int[MAX_PORTAL];
            portal_pos = new int[MAX_PORTAL];
            timer = new Timer(40, this);
            timer.start();

        }

        private void playGame(Graphics2D g2d) { //game play

            if (dying) {

                death();

            } else {

                movePacman();
                drawPacman(g2d);
                moveGhosts(g2d);
                checkMaze(g2d);
            }
        }

        private void showIntroScreen(Graphics2D g2d) {

            String start = "Press SPACE to start";
            g2d.setColor(Color.yellow);
            g2d.drawString(start, (SCREEN_SIZEHEIGHT)/4+145, 85);
        }
        private void showMessageNextLevel(Graphics2D g2d, int numLevel) {
            String next = "Level " + numLevel;
            g2d.setColor(Color.yellow);
            g2d.drawString(next, (SCREEN_SIZEHEIGHT)/4+170, 140);
        }
        private void showMessageEnd(Graphics2D g2d) {
            String end = "You won. Press 'Enter' to restart.";
            g2d.setColor(Color.yellow);
            g2d.drawString(end, (SCREEN_SIZEHEIGHT)/4+130, 200);
        }
        private void drawScore(Graphics2D g) {
            g.setFont(smallFont);
            g.setColor(new Color(255, 0, 70));
            String s = "Score: " + score;
            g.drawString(s, SCREEN_SIZEWIDTH / 2 + 96, SCREEN_SIZEHEIGHT + 16);

            for (int i = 0; i < lives; i++) {
                g.drawImage(heart, i * 28 + 8, SCREEN_SIZEHEIGHT + 1, this);
            }
        }
        private void drawLevel(Graphics2D g) {
            g.setFont(smallFont);
            g.setColor(new Color(255, 0, 70));
            String s = "Level: " + currentLevel;
            g.drawString(s, SCREEN_SIZEWIDTH / 2 + 200, SCREEN_SIZEHEIGHT + 16);
        }
        private void checkMaze(Graphics2D g2d) {
            //n += countDot();
            if(score == DOT_1|| score == DOT_1 + DOT_2) {

                nextLevel(g2d);
            }
            if(score == DOT_1 + DOT_2 + DOT_3) {
                //showMessageEnd(g2d);
                inGame = false;
                isRS = true;
            }
        }
//        int i = 0;
//        n += countDot(screenData);
//        boolean finished = true;
//
//        while (i < N_BLOCKSWIDTH * N_BLOCKSHEIGHT && finished) {
//
//            if (score < n) {
//                finished = false;
//            }
//
//            i++;
//        }

//        if (finished) {
//            if (N_GHOSTS < MAX_GHOSTS) {
//                N_GHOSTS++;
//            }
//
//            if (currentSpeed < maxSpeed) {
//                currentSpeed++;
//            }
//            initLevel(levelData);
        //initLevel(levelData1);

//        }

        private void death() {

            lives--;

            if (lives == 0) {
                inGame = false;
            }

            continueLevel();
        }

        private void moveGhosts(Graphics2D g2d) {

            int pos;
            int count;

            for (int i = 0; i < N_GHOSTS; i++) {
                if (ghost_x[i] % BLOCK_SIZE == 0 && ghost_y[i] % BLOCK_SIZE == 0) {
                    pos = ghost_x[i] / BLOCK_SIZE + N_BLOCKSWIDTH * (int) (ghost_y[i] / BLOCK_SIZE);

                    count = 0;

                    if ((screenData[pos] & 1) == 0 && ghost_dx[i] != 1) {
                        dx[count] = -1;
                        dy[count] = 0;
                        count++;
                    }

                    if ((screenData[pos] & 2) == 0 && ghost_dy[i] != 1) {
                        dx[count] = 0;
                        dy[count] = -1;
                        count++;
                    }

                    if ((screenData[pos] & 4) == 0 && ghost_dx[i] != -1) {
                        dx[count] = 1;
                        dy[count] = 0;
                        count++;
                    }

                    if ((screenData[pos] & 8) == 0 && ghost_dy[i] != -1) {
                        dx[count] = 0;
                        dy[count] = 1;
                        count++;
                    }

                    if (count == 0) {

                        if ((screenData[pos] & 15) == 15) {
                            ghost_dx[i] = 0;
                            ghost_dy[i] = 0;
                        } else {
                            ghost_dx[i] = -ghost_dx[i];
                            ghost_dy[i] = -ghost_dy[i];
                        }

                    } else {

                        count = (int) (Math.random() * count);

                        if (count > 3) {
                            count = 3;
                        }

                        ghost_dx[i] = dx[count];
                        ghost_dy[i] = dy[count];
                    }

                }

                ghost_x[i] = ghost_x[i] + (ghost_dx[i] * ghostSpeed[i]);
                ghost_y[i] = ghost_y[i] + (ghost_dy[i] * ghostSpeed[i]);
                drawGhost(g2d, ghost_x[i] + 1, ghost_y[i] + 1);

                if (pacman_x > (ghost_x[i] - 12) && pacman_x < (ghost_x[i] + 12)
                        && pacman_y > (ghost_y[i] - 12) && pacman_y < (ghost_y[i] + 12)
                        && inGame) {

                    dying = true;
                }

            }
        }

        private void drawGhost(Graphics2D g2d, int x, int y) {
            g2d.drawImage(ghost, x, y, this);
        }

        private void movePacman() {

            int pos;
            short ch;

            if (pacman_x % BLOCK_SIZE == 0 && pacman_y % BLOCK_SIZE == 0) {
                pos = pacman_x / BLOCK_SIZE + N_BLOCKSWIDTH * (int) (pacman_y / BLOCK_SIZE);
                ch = screenData[pos];

//            if((ch&32)!=0) {
//            	if(pos==pp[0]) {
//            		pacman_x = ((pp[1] % N_BLOCKSWIDTH))*BLOCK_SIZE;
//            		pacman_y = ((int)(pp[1] / N_BLOCKSWIDTH))*BLOCK_SIZE;
//            	}else if(pos==pp[1]) {
//            		pacman_x = ((pp[0] % N_BLOCKSWIDTH))*BLOCK_SIZE;
//            		pacman_y = ((int)(pp[0] / N_BLOCKSWIDTH))*BLOCK_SIZE;
//            	}
//            }
                if((ch & 64)!=0){
                    if(portal_pos[0]==pos) {
                        pacman_x = portal_x[1];
                        pacman_y = portal_y[1];
                    } else {
                        pacman_x = portal_x[0];
                        pacman_y = portal_y[0];
                    }
                }
                if ((ch & 16) != 0) {
                    screenData[pos] = (short) (ch & 15);
                    score++;
                }
                if (req_dx != 0 || req_dy != 0) {
                    if (!((req_dx == -1 && req_dy == 0 && (ch & 1) != 0)
                            || (req_dx == 1 && req_dy == 0 && (ch & 4) != 0)
                            || (req_dx == 0 && req_dy == -1 && (ch & 2) != 0)
                            || (req_dx == 0 && req_dy == 1 && (ch & 8) != 0))) {
                        pacmand_x = req_dx;
                        pacmand_y = req_dy;
                    }
                }

                // Check for standstill
                if ((pacmand_x == -1 && pacmand_y == 0 && (ch & 1) != 0)
                        || (pacmand_x == 1 && pacmand_y == 0 && (ch & 4) != 0)
                        || (pacmand_x == 0 && pacmand_y == -1 && (ch & 2) != 0)
                        || (pacmand_x == 0 && pacmand_y == 1 && (ch & 8) != 0)) {
                    pacmand_x = 0;
                    pacmand_y = 0;
                }
            }
            pacman_x = pacman_x + PACMAN_SPEED * pacmand_x;
            pacman_y = pacman_y + PACMAN_SPEED * pacmand_y;
        }

        private void drawPacman(Graphics2D g2d) {

            if (req_dx == -1) {
                g2d.drawImage(left, pacman_x + 1, pacman_y + 1, this);
            } else if (req_dx == 1) {
                g2d.drawImage(right, pacman_x + 1, pacman_y + 1, this);
            } else if (req_dy == -1) {
                g2d.drawImage(up, pacman_x + 1, pacman_y + 1, this);
            } else {
                g2d.drawImage(down, pacman_x + 1, pacman_y + 1, this);
            }
        }

        private void drawMaze(Graphics2D g2d) {
            nPortal = 0;
            short i = 0;
            int x, y;

            for (y = 0; y < SCREEN_SIZEHEIGHT; y += BLOCK_SIZE) {
                for (x = 0; x < SCREEN_SIZEWIDTH; x += BLOCK_SIZE) {

                    g2d.setColor(new Color(102,51,0)); // set mau xanh (blue)
                    g2d.setStroke(new BasicStroke(5));

                    if ((clearArr[i] == 0)) {
                        g2d.drawImage(wall, x, y, null);
                        // g2d.fillRect(x, y, BLOCK_SIZE, BLOCK_SIZE); // ve hinh chu nhat do mau (blue)
                    }
                    if((clearArr[i] & 64)!=0) {
                        portal_x[nPortal] = x;
                        portal_y[nPortal] = y;
                        portal_pos[nPortal] = x / BLOCK_SIZE + N_BLOCKSWIDTH * (int) (y / BLOCK_SIZE);
                        nPortal++;
                        g2d.drawImage(portal, x, y, null);
                    }

                    if ((screenData[i] & 1) != 0) {
                        g2d.drawLine(x, y, x, y + BLOCK_SIZE - 1);
                    }

                    if ((screenData[i] & 2) != 0) {
                        g2d.drawLine(x, y, x + BLOCK_SIZE - 1, y);
                    }

                    if ((screenData[i] & 4) != 0) {
                        g2d.drawLine(x + BLOCK_SIZE - 1, y, x + BLOCK_SIZE - 1,
                                y + BLOCK_SIZE - 1);
                    }

                    if ((screenData[i] & 8) != 0) {
                        g2d.drawLine(x, y + BLOCK_SIZE - 1, x + BLOCK_SIZE - 1,
                                y + BLOCK_SIZE - 1);
                    }

                    if ((screenData[i] & 16) != 0) {
                        g2d.setColor(new Color(255,255,255));
                        g2d.fillOval(x + 10, y + 10, 6, 6);
                    }

                    i++;
                }
            }
        }
        private void initGame() {
            isRS = false;
            currentLevel = 1;
            clearArr = levelData;
            nLevel = 3;
            lives = 10;
            score = 0;
            initLevel(levelData);
            N_GHOSTS = 1;
            currentSpeed = 4;
        }

        private void initLevel(short[] levelData) {

            int i;
            for (i = 0; i < N_BLOCKSWIDTH * N_BLOCKSHEIGHT; i++) {
                screenData[i] = levelData[i];
            }

            continueLevel();
        }

        private void continueLevel() {

            int dx = 1;
            int random;

            for (int i = 0; i < N_GHOSTS; i++) {

                ghost_y[i] = 6 * BLOCK_SIZE; //start position
                ghost_x[i] = 12 * BLOCK_SIZE;
                ghost_dy[i] = 0;
                ghost_dx[i] = dx;
                dx = -dx;
                random = (int) (Math.random() * (currentSpeed + 1));

                if (random > currentSpeed) {
                    random = currentSpeed;
                }

                ghostSpeed[i] = validSpeeds[random];
            }

            pacman_x = 12 * BLOCK_SIZE;  //start position
            pacman_y = 12 * BLOCK_SIZE;
            pacmand_x = 0;	//reset direction move
            pacmand_y = 0;
            req_dx = 0;		// reset direction controls
            req_dy = 0;
            dying = false;
        }
        private void nextLevel(Graphics2D g2d) {
            currentLevel += 1;
            lives += 1;
            N_GHOSTS += 1;
            if(currentLevel == 2) {
                clearArr = levelData1;
                initLevel(levelData1);
                paintComponent(g2d);
            }
            if(currentLevel == 3) {
                clearArr = levelData2;
                initLevel(levelData2);
                paintComponent(g2d);
            }
        }
        private void reStart() {
            isRS = false;
            inGame = true;
            initGame();
        }
        //    public void clearMaze(Graphics g2d) {
//    	short i = 0;
//        int x, y;
//
//        for (y = 0; y < SCREEN_SIZEHEIGHT; y += BLOCK_SIZE) {
//            for (x = 0; x < SCREEN_SIZEWIDTH; x += BLOCK_SIZE) {
//
//                g2d.setColor(new Color(0,0,0)); // set mau xanh (blue)
//                ((Graphics2D) g2d).setStroke(new BasicStroke(5));
//
//                if ((clearArr[i] == 0)) {
//                    g2d.drawImage(wall, x, y, null);
//                	// g2d.fillRect(x, y, BLOCK_SIZE, BLOCK_SIZE); // ve hinh chu nhat do mau (blue)
//                 }
//                if((clearArr[i] & 32)!=0) {
//                	g2d.drawImage(portal, x, y, null);
//                }
//
//                if ((screenData[i] & 1) != 0) {
//                    g2d.drawLine(x, y, x, y + BLOCK_SIZE - 1);
//                }
//
//                if ((screenData[i] & 2) != 0) {
//                    g2d.drawLine(x, y, x + BLOCK_SIZE - 1, y);
//                }
//
//                if ((screenData[i] & 4) != 0) {
//                    g2d.drawLine(x + BLOCK_SIZE - 1, y, x + BLOCK_SIZE - 1,
//                            y + BLOCK_SIZE - 1);
//                }
//
//                if ((screenData[i] & 8) != 0) {
//                    g2d.drawLine(x, y + BLOCK_SIZE - 1, x + BLOCK_SIZE - 1,
//                            y + BLOCK_SIZE - 1);
//                }
//
//                if ((screenData[i] & 16) != 0) {
//                    g2d.setColor(new Color(0,0,0));
//                    g2d.fillOval(x + 10, y + 10, 6, 6);
//               }
//
//                i++;
//            }
//        }
//    }
        public void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2d = (Graphics2D) g;

            g2d.setColor(Color.black);
            g2d.fillRect(0, 0, 620, 420);
            //drawPacman(g2d);
            drawMaze(g2d);
            drawScore(g2d);
            drawLevel(g2d);

            if (inGame) {
                if(currentLevel <= nLevel)playGame(g2d);
            } else {
                if(isRS == false){
                    showIntroScreen(g2d);
                    showMessageNextLevel(g2d, currentLevel);
                } else {
                    showMessageEnd(g2d);
                }
            }

            Toolkit.getDefaultToolkit().sync();
            g2d.dispose();
        }


        //controls
        class TAdapter extends KeyAdapter {

            @Override
            public void keyPressed(KeyEvent e) {

                int key = e.getKeyCode();

                if (inGame) {
                    if (key == KeyEvent.VK_LEFT) {
                        req_dx = -1;
                        req_dy = 0;
                    } else if (key == KeyEvent.VK_RIGHT) {
                        req_dx = 1;
                        req_dy = 0;
                    } else if (key == KeyEvent.VK_UP) {
                        req_dx = 0;
                        req_dy = -1;
                    } else if (key == KeyEvent.VK_DOWN) {
                        req_dx = 0;
                        req_dy = 1;
                    } else if (key == KeyEvent.VK_ESCAPE && timer.isRunning()) {
                        inGame = false;
                    }
                } else {
                    if (key == KeyEvent.VK_SPACE && isRS == false) {
                        inGame = true;
                        initGame();
                    }
                    if(key == KeyEvent.VK_ENTER && isRS == true) {
                        reStart();
                    }
                }
            }
        }


        public void actionPerformed(ActionEvent e) {
            repaint();
        }


        public Dimension getD() {
            return d;
        }


        public void setD(Dimension d) {
            this.d = d;
        }

    }


