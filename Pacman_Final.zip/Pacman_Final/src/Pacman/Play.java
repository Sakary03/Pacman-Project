package Pacman;

import javax.swing.JFrame;


public class Play extends JFrame {


    private static final long serialVersionUID = 1L;
    public Play() {
        add(new OtherComponents());
    }
    public static void main(String[] args) {
        Game.PlayGame pac = new Game.PlayGame();
        pac.setVisible(true);
        pac.setTitle("Pacman");
        pac.setSize(620,420);
        pac.setDefaultCloseOperation(EXIT_ON_CLOSE);
        pac.setLocationRelativeTo(null);

    }

}


