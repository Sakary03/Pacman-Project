package Pacman;

import javax.swing.*;
import java.awt.event.ActionListener;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
public class OtherComponents extends JPanel implements ActionListener {
    Ghost ghostNew =new Ghost();
    Pacman pacmanNew=new Pacman();
    Map mapNew =new Map();


    protected static final long serialVersionUID = 1L;
    private Dimension d;
    protected final Font smallFont = new Font("Times New Roman", Font.BOLD, 14);
    protected boolean inGame = false;
    protected boolean dying = false;
    protected int nLevel = 2;
    protected int currentLevel = 1;
    protected boolean isRS = false;

    protected final int BLOCK_SIZE = 24;
    protected final int N_BLOCKSWIDTH = 25;

    protected final int N_BLOCKSHEIGHT = 15;
    protected final int SCREEN_SIZEWIDTH = N_BLOCKSWIDTH * BLOCK_SIZE;
    protected final int SCREEN_SIZEHEIGHT = N_BLOCKSHEIGHT * BLOCK_SIZE;
    protected int lives, score;
    protected int[] dx, dy;

    protected Image heart, ghost, portal;
    protected Image up, down, left, right, wall;


    int nPortal;

    protected short clearArr[];


    public short[] screenData;
    private Timer timer;

    public OtherComponents() {

        loadImages();
        initVariables();
        addKeyListener(new TAdapter());
        setFocusable(true);
        initGame();
    }


    public void loadImages() {
        down = new ImageIcon(this.getClass().getResource("/images/down.gif")).getImage();
        up = new ImageIcon(this.getClass().getResource("/images/up.gif")).getImage();
        left = new ImageIcon(this.getClass().getResource("/images/left.gif")).getImage();
        right = new ImageIcon(this.getClass().getResource("/images/right.gif")).getImage();
        ghost = new ImageIcon(this.getClass().getResource("/images/ghost.gif")).getImage();
        portal = new ImageIcon(this.getClass().getResource("/images/portal.gif")).getImage();
        heart = new ImageIcon(this.getClass().getResource("/images/heart.png")).getImage();
        wall = new ImageIcon(this.getClass().getResource("/images/wall.png")).getImage();

    }
    public void initVariables() {

        screenData = new short[N_BLOCKSWIDTH * N_BLOCKSHEIGHT];
        setD(new Dimension(400, 400));

        ghostNew.setGhost();
        dx = new int[4];
        dy = new int[4];
        mapNew.setPortal();
        timer = new Timer(40, this);
        timer.start();

    }

    public void playGame(Graphics2D g2d) { //game play

        if (dying) {

            death();

        } else {

            pacmanNew.movePacman();
            pacmanNew.drawPacman(g2d);
            ghostNew.moveGhosts(g2d);
            mapNew.checkMaze(g2d);
        }
    }

    public void showIntroScreen(Graphics2D g2d) {

        String start = "Press SPACE to start";
        g2d.setColor(Color.yellow);
        g2d.drawString(start, (SCREEN_SIZEHEIGHT)/4+145, 85);
    }
    public void showMessageNextLevel(Graphics2D g2d, int numLevel) {
        String next = "Level " + numLevel;
        g2d.setColor(Color.yellow);
        g2d.drawString(next, (SCREEN_SIZEHEIGHT)/4+170, 140);
    }
    public void showMessageEnd(Graphics2D g2d) {
        String end = "You won. Press 'Enter' to restart.";
        g2d.setColor(Color.yellow);
        g2d.drawString(end, (SCREEN_SIZEHEIGHT)/4+130, 200);
    }
    public void drawScore(Graphics2D g) {
        g.setFont(smallFont);
        g.setColor(new Color(255, 0, 70));
        String s = "Score: " + score;
        g.drawString(s, SCREEN_SIZEWIDTH / 2 + 96, SCREEN_SIZEHEIGHT + 16);

        for (int i = 0; i < lives; i++) {
            g.drawImage(heart, i * 28 + 8, SCREEN_SIZEHEIGHT + 1, this);
        }
    }
    public void drawLevel(Graphics2D g) {
        g.setFont(smallFont);
        g.setColor(new Color(255, 0, 70));
        String s = "Level: " + currentLevel;
        g.drawString(s, SCREEN_SIZEWIDTH / 2 + 200, SCREEN_SIZEHEIGHT + 16);
    }
    public void death() {

        lives--;

        if (lives == 0) {
            inGame = false;
        }

        continueLevel();
    }

    public void drawGhost(Graphics2D g2d, int x, int y) {
        g2d.drawImage(ghost, x, y, this);
    }

    private void initGame() {
        isRS = false;
        currentLevel = 1;
        clearArr = mapNew.getLevelData();
        nLevel = 3;
        lives = 10;
        score = 0;
        initLevel(mapNew.getLevelData());
        ghostNew.setN_GHOSTS(1);
        ghostNew.setCurrentSpeed(4);
    }

    private void initLevel(short[] levelData) {

        int i;
        for (i = 0; i < N_BLOCKSWIDTH * N_BLOCKSHEIGHT; i++) {
            screenData[i] = levelData[i];
        }

        continueLevel();
    }

    private void continueLevel() {

        int dx = 1;
        int random;

        for (int i = 0; i < ghostNew.getN_GHOSTS(); i++) {

            ghostNew.setGhost_y(i, 6 * BLOCK_SIZE); //start position
            ghostNew.setGhost_x(i,12 * BLOCK_SIZE);
            ghostNew.setGhost_dy(i, 0);
            ghostNew.setGhost_dx(i, dx);
            dx = -dx;
            random = (int) (Math.random() * (ghostNew.getCurrentSpeed() + 1));

            if (random > ghostNew.getCurrentSpeed()) {
                random = ghostNew.getCurrentSpeed();
            }

            ghostNew.setGhostSpeed(i, ghostNew.getValidSpeeds(random));
        }

        pacmanNew.setPacman_x( 12 * BLOCK_SIZE);  //start position
        pacmanNew.setPacman_y( 12 * BLOCK_SIZE);
        pacmanNew.setPacmand_x (0);	//reset direction move
        pacmanNew.setPacmand_y (0);
        pacmanNew.setReq_dx( 0);		// reset direction controls
        pacmanNew.setReq_dy( 0);
        dying = false;
    }
    public void nextLevel(Graphics2D g2d) {
        currentLevel += 1;
        lives += 1;
        int numghost=ghostNew.getN_GHOSTS();
        numghost++;
        ghostNew.setN_GHOSTS( numghost);
        if(currentLevel == 2) {
            clearArr = mapNew.getLevelData1();
            initLevel(mapNew.getLevelData1());
            paintComponent(g2d);
        }
        if(currentLevel == 3) {
            clearArr = mapNew.getLevelData2();
            initLevel(mapNew.getLevelData2());
            paintComponent(g2d);
        }
    }
    private void reStart() {
        isRS = false;
        inGame = true;
        initGame();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.setColor(Color.black);
        g2d.fillRect(0, 0, 620, 420);
        //drawPacman(g2d);
        mapNew.drawMaze(g2d);
        drawScore(g2d);
        drawLevel(g2d);

        if (inGame) {
            if(currentLevel <= nLevel)playGame(g2d);
        } else {
            if(isRS == false){
                showIntroScreen(g2d);
                showMessageNextLevel(g2d, currentLevel);
            } else {
                showMessageEnd(g2d);
            }
        }

        Toolkit.getDefaultToolkit().sync();
        g2d.dispose();
    }


    //controls
    class TAdapter extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {

            int key = e.getKeyCode();

            if (inGame) {
                if (key == KeyEvent.VK_LEFT) {
                    pacmanNew.setReq_dx( -1);
                    pacmanNew.setReq_dy( 0);
                } else if (key == KeyEvent.VK_RIGHT) {
                    pacmanNew.setReq_dx( 1);
                    pacmanNew.setReq_dy( 0);
                } else if (key == KeyEvent.VK_UP) {
                    pacmanNew.setReq_dx( 0);
                    pacmanNew.setReq_dy( -1);
                } else if (key == KeyEvent.VK_DOWN) {
                    pacmanNew.setReq_dx( 0);
                    pacmanNew.setReq_dy( 1);
                } else if (key == KeyEvent.VK_ESCAPE && timer.isRunning()) {
                    inGame = false;
                }
            } else {
                if (key == KeyEvent.VK_SPACE && isRS == false) {
                    inGame = true;
                    initGame();
                }
                if(key == KeyEvent.VK_ENTER && isRS == true) {
                    reStart();
                }
            }
        }
    }


    public void actionPerformed(ActionEvent e) {
        repaint();
    }


    public Dimension getD() {
        return d;
    }


    public void setD(Dimension d) {
        this.d = d;
    }

}


