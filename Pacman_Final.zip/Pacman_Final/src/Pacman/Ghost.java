package Pacman;

import java.awt.*;

public class Ghost extends OtherComponents {
    public Ghost(){

    }
    private final int MAX_GHOSTS = 8;
    protected int N_GHOSTS = 6;

    public int getN_GHOSTS() {
        return N_GHOSTS;
    }

    public void setN_GHOSTS(int n_GHOSTS) {
        N_GHOSTS = n_GHOSTS;
    }

    protected int[] ghost_x, ghost_y, ghost_dx, ghost_dy, ghostSpeed;

    public int[] getGhost_x() {
        return ghost_x;
    }

    public void setGhost_x(int i, int x) {
        this.ghost_x[i] = x;
    }

    public int[] getGhost_y() {
        return ghost_y;
    }

    public void setGhost_y(int i, int y) {
        this.ghost_y[i] = y;
    }

    public int[] getGhost_dx() {
        return ghost_dx;
    }

    public void setGhost_dx(int i, int x) {
        this.ghost_dy[i] = x;
    }

    public int[] getGhost_dy() {
        return ghost_dy;
    }

    public void setGhost_dy(int i, int y) {
        this.ghost_dy[i] = y;
    }

    public int[] getGhostSpeed() {
        return ghostSpeed;
    }

    public void setGhostSpeed(int i, int ghostSpeed) {
        this.ghostSpeed[i] = ghostSpeed;
    }

    protected final int validSpeeds[] = {1, 2, 3, 4, 6, 8};
    //private final int maxSpeed = 6;

    public int getValidSpeeds(int i) {
        return validSpeeds[i];
    }

    protected int currentSpeed = 3;

    public int getCurrentSpeed() {
        return currentSpeed;
    }

    public void setCurrentSpeed(int currentSpeed) {
        this.currentSpeed = currentSpeed;
    }

    public void setGhost(){
        ghost_x = new int[MAX_GHOSTS];
        ghost_dx = new int[MAX_GHOSTS];
        ghost_y = new int[MAX_GHOSTS];
        ghost_dy = new int[MAX_GHOSTS];
        ghostSpeed = new int[MAX_GHOSTS];
    }


    protected void moveGhosts(Graphics2D g2d) {

        int pos;
        int count;

        for (int i = 0; i < N_GHOSTS; i++) {
            if (ghost_x[i] % BLOCK_SIZE == 0 && ghost_y[i] % BLOCK_SIZE == 0) {
                pos = ghost_x[i] / BLOCK_SIZE + N_BLOCKSWIDTH * (int) (ghost_y[i] / BLOCK_SIZE);

                count = 0;

                if ((screenData[pos] & 1) == 0 && ghost_dx[i] != 1) {
                    dx[count] = -1;
                    dy[count] = 0;
                    count++;
                }

                if ((screenData[pos] & 2) == 0 && ghost_dy[i] != 1) {
                    dx[count] = 0;
                    dy[count] = -1;
                    count++;
                }

                if ((screenData[pos] & 4) == 0 && ghost_dx[i] != -1) {
                    dx[count] = 1;
                    dy[count] = 0;
                    count++;
                }

                if ((screenData[pos] & 8) == 0 && ghost_dy[i] != -1) {
                    dx[count] = 0;
                    dy[count] = 1;
                    count++;
                }

                if (count == 0) {

                    if ((screenData[pos] & 15) == 15) {
                        ghost_dx[i] = 0;
                        ghost_dy[i] = 0;
                    } else {
                        ghost_dx[i] = -ghost_dx[i];
                        ghost_dy[i] = -ghost_dy[i];
                    }

                } else {

                    count = (int) (Math.random() * count);

                    if (count > 3) {
                        count = 3;
                    }

                    ghost_dx[i] = dx[count];
                    ghost_dy[i] = dy[count];
                }

            }

            ghost_x[i] = ghost_x[i] + (ghost_dx[i] * ghostSpeed[i]);
            ghost_y[i] = ghost_y[i] + (ghost_dy[i] * ghostSpeed[i]);
            drawGhost(g2d, ghost_x[i] + 1, ghost_y[i] + 1);

            if (pacmanNew.getPacman_x() > (ghost_x[i] - 12) && pacmanNew.getPacman_x() < (ghost_x[i] + 12)
                    && pacmanNew.getPacman_y() > (ghost_y[i] - 12) && pacmanNew.getPacman_y() < (ghost_y[i] + 12)
                    && inGame) {

                dying = true;
            }

        }
    }

}
